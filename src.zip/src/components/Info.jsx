import React from "react";
import SectionWrapper from "./SectionWrapper";
import { Icon } from "@iconify/react";

export default function Info() {
  const fincaLocation =
    "Finca Hotel Andaquies, Vía Armenia - Montenegro, Salida 2 #km 4, Armenia, Quindío";
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    fincaLocation
  )}`;

  return (
    <SectionWrapper
      id="info"
      className="relative bg-gradient-to-b from-gray-950 to-gray-900"
    >
      {/* Título de la sección */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-600/20 text-emerald-300 text-sm font-medium mb-4">
          <Icon icon="mdi:information" className="text-lg" />
          Información del Campamento
        </div>
        <h2 className="font-display text-4xl sm:text-5xl font-bold text-white mb-4">
          Detalles Importantes
        </h2>
        <p className="text-gray-400 text-lg max-w-2xl mx-auto">
          Todo lo que necesitas saber para participar en esta experiencia única
        </p>
      </div>

      {/* Tarjetas de información */}
      <div className="grid md:grid-cols-3 gap-8">
        {/* Tarjeta de Fecha */}
        <div className="inline-block h-fit p-8 rounded-2xl bg-gradient-to-br from-emerald-600/10 to-emerald-700/10 border border-emerald-500/20">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="p-3 rounded-xl bg-emerald-600/20 text-emerald-400">
              <Icon icon="mdi:calendar-star" className="text-3xl" />
            </div>
            <h3 className="text-2xl font-bold text-white">Fecha</h3>
          </div>

          {/* Fecha principal más prominente */}
          <div className="text-center">
            <div className="mb-4">
              <div className="text-4xl md:text-5xl font-bold text-emerald-300 mb-2 leading-tight">
                10-13
              </div>
              <div className="text-2xl font-semibold text-white mb-1">
                Octubre
              </div>
              <div className="text-lg text-emerald-200 font-medium">2025</div>
            </div>

            <div className="pt-4 border-t border-emerald-500/20">
              <div className="text-sm text-gray-300 mb-1">Duración</div>
              <div className="text-lg font-semibold text-white">
                4 días / 3 noches
              </div>
            </div>
          </div>
        </div>

        {/* Tarjeta de Contacto */}
        <div className="inline-block p-8 rounded-2xl bg-gradient-to-br from-emerald-600/10 to-emerald-700/10 border border-emerald-500/20">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="p-3 rounded-xl bg-emerald-600/20 text-emerald-400">
              <Icon icon="mdi:phone" className="text-3xl" />
            </div>
            <h3 className="text-2xl font-bold text-white">Contacto</h3>
          </div>

          {/* Lista de contactos */}
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-sm text-emerald-300 font-medium mb-1">
                Coordinador General
              </div>
              <div className="text-lg font-semibold text-white">
                Pastor Juan Carlos
              </div>
              <div className="text-emerald-200 font-mono">300-240-7641</div>
            </div>

            <div className="border-t border-emerald-500/20 pt-3">
              <div className="text-center">
                <div className="text-sm text-emerald-300 font-medium mb-1">
                  Coordinadora Logística
                </div>
                <div className="text-lg font-semibold text-white">
                  Hermana María
                </div>
                <div className="text-emerald-200 font-mono">310-555-1234</div>
              </div>
            </div>

            <div className="border-t border-emerald-500/20 pt-3">
              <div className="text-center">
                <div className="text-sm text-emerald-300 font-medium mb-1">
                  Actividades
                </div>
                <div className="text-lg font-semibold text-white">
                  Líder David
                </div>
                <div className="text-emerald-200 font-mono">315-678-9012</div>
              </div>
            </div>

            <div className="border-t border-emerald-500/20 pt-3">
              <div className="text-center">
                <div className="text-sm text-emerald-300 font-medium mb-1">
                  Emergencias
                </div>
                <div className="text-lg font-semibold text-white">
                  Pastor Miguel
                </div>
                <div className="text-emerald-200 font-mono">320-987-6543</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tarjeta de Ubicación */}
        <div className="inline-block h-fit p-8 rounded-2xl bg-gradient-to-br from-emerald-600/10 to-emerald-700/10 border border-emerald-500/20">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="p-3 rounded-xl bg-emerald-600/20 text-emerald-400">
              <Icon icon="mdi:map-marker" className="text-2xl" />
            </div>
            <h3 className="text-xl font-semibold text-white">
              Ubicación del Campamento
            </h3>
          </div>
          <p className="text-gray-300 mb-6 text-center leading-relaxed">
            {fincaLocation}
          </p>
          <div className="text-center pt-4 border-t border-emerald-500/20">
            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl"
            >
              <Icon icon="mdi:google-maps" className="text-lg" />
              Ver en Maps
              <Icon icon="mdi:external-link" className="text-sm" />
            </a>
          </div>
        </div>
      </div>
    </SectionWrapper>
  );
}
