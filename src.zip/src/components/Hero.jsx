import React from "react";
import { Icon } from "@iconify/react";

export default function Hero({ data, onPrimaryClick }) {
  return (
    <div className="relative min-h-[88vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        {/* Imagen de fallback */}
        <div className="absolute inset-0 bg-[url('/hero/hero-bg-1.jpg')] bg-cover bg-center" />

        {/* Video de fondo */}
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
          onLoadStart={() => console.log("Video started loading")}
          onCanPlay={() => console.log("Video can play")}
          onError={(e) => {
            console.log("Error loading video:", e);
            e.target.style.display = "none";
          }}
        >
          <source src="/hero/camp-video.msp4" type="video/mp4" />
        </video>

        {/* Overlay oscuro para mejorar legibilidad */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-black/70 to-black/80" />
        <div className="absolute inset-0 bg-neutral-900/20" />
      </div>
      <div className="max-w-4xl mx-auto px-6 text-center text-white animate-fadeIn relative z-10">
        <div className="mb-8 flex justify-center">
          <img
            src="/dark_logo-og.png"
            alt="Camp La Semilla Logo"
            className="h-40 md:h-52 lg:h-72 w-auto drop-shadow-lg"
          />
        </div>
        <p className="text-sm uppercase tracking-widest text-emerald-300 mb-4 flex items-center justify-center gap-2">
          <Icon
            icon="mdi:seed-outline"
            className="text-emerald-400 text-xl hidden sm:flex"
          />
          {data.date} • {data.location}
        </p>
        <h1 className="font-display text-4xl sm:text-6xl font-bold leading-tight text-white drop-shadow">
          {data.title}
        </h1>
        <p className="mt-6 text-lg sm:text-xl text-emerald-100/90 font-light">
          {data.subtitle}
        </p>
        <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#inscripcion"
            onClick={onPrimaryClick}
            className="group text-center relative overflow-hidden inline-flex items-center gap-3 px-12 py-5 rounded-2xl cursor-pointer bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 active:scale-[0.97] text-white font-bold text-lg tracking-wide shadow-2xl shadow-emerald-600/40 hover:shadow-emerald-400/50 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-emerald-300/50"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
            <Icon icon="mdi:rocket-launch" className="text-2xl relative z-10" />
            <span className="relative z-10">{data.ctaPrimary}</span>
            <Icon
              icon="mdi:arrow-right"
              className="text-xl relative z-10 group-hover:translate-x-1 transition-transform"
            />
          </a>
          <a
            href="#actividades"
            className="inline-flex items-center justify-center px-8 py-4 rounded-xl font-medium bg-white/10 hover:bg-white/15 backdrop-blur text-white border border-white/10 transition-colors"
          >
            <Icon icon="mdi:compass" className="mr-2 text-lg" />{" "}
            {data.ctaSecondary}
          </a>
        </div>
      </div>
    </div>
  );
}
