## Misión del Campamento
Sembrar principios eternos en la vida de niños y jóvenes por medio de experiencias vivenciales, comunidad y conexión con Dios en medio de la naturaleza.

## Enfoque
El programa integra: formación espiritual, recreación creativa, servicio comunitario y desarrollo de liderazgo.

## Visión
Ver una generación apasionada por Cristo que transforma su entorno.
